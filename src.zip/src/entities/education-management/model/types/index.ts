export interface FamilyDirectionItem {
  id: number
  cipher: string
  kind: number
  direction_name: string
}

export interface FamilyDirection {
  id: number
  code: string | null
  title: string
  direction: FamilyDirectionItem[]
}

export type Direction = {
  id: number;
  code: string | null;
  title: string;
};

export type Discipline = {
  id: number;
  kind: number;
  level_education: "bachelor" | "master" | "specialist";
  level_edu: string;
  form_edu: string;
  form_education: "full_time" | "part_time" | "distance";
  year: string;
  label: string;
  creator_name: string;
};
export interface KindDirectionItem {
  id: number;
  cipher: string;
  kind: number;
  direction_name: string;
}

export interface KindDirection {
  id: number;
  code: string | null;
  title: string;
  direction: KindDirectionItem[];
}

export type SelectOptions = {
  value: number;
  label: string;
};

export type WorkPlanItem = {
  id: number;
  number: number;
  name_subject: string;
  stream_type: string;
  teacher: number;
  teacher_name: string;
  status: string;
  students_count: number;
  capacity: number;
};
export interface TeacherHours {
  [teacherName: string]: {
    aud: number
    out: number
  }
}

export interface Subject {
  name: string
  credit: number
  semester: string
  direction: string
  streams: string[]
  students_count: number
  contract_stud: number
  budget_stud: number
  lecture: number
  practice: number
  lab: number
  consult_control: number
  rgr_rgz: number
  cw_cp: number
  vkr: number
  phd: number
  seminar: number
  aspirant: number
  doct_consult: number
  visit: number
  practice_supervise: number
  oop: number
  gak: number
  teachers_hours: TeacherHours
  total: number
}

export interface WorkLoad {
  subjects: Subject[]
  teachers: string[]
}
export interface Syllabus {
  id: number
  cipher: string
  direction: string
  duration: number
  years: string
  semesters: number
  profile_id: number
  profile: string
  subjects: number
}

export interface Reports {
  id: number
  institute: string
  syllabuses: Syllabus[]
}

export interface SyllabusCourse {
  id: number;
  code: string | null; // can be null in data.txt (e.g., diploma work)
  name_subject: string;
  dep: string;
  cycle: string | null;
  course_type: string; // e.g., "Базовая часть" | "Вузовский компонент" | "Курс по выбору"
  control_form: string; // e.g., "Экзамен" | "Зачет" | "Курс/пр"
  credit: number;
  amount_hours: number;
  lecture_hours: number;
  practice_hours: number;
  lab_hours: number;
}

export interface SyllabusSemester {
  id: number;
  name_semester: string;
  count_credit: number;
  lecture_hours: number;
  lab_hours: number;
  practice_hours: number;
  amount_hours: number;
  courses: SyllabusCourse[];
  elective_course: SyllabusCourse[][]; // array of groups of elective courses
  profiles_name?: { id: number; title: string; courses: unknown[]; elective_courses: SyllabusCourse[][] }[];
}

export interface SyllabusRoot {
  id: number;
  direction: string;
  profile: string;
  form_education: string;
  duration: number;
  start_year: number;
  end_year: number;
  semesters: SyllabusSemester[];
  // Optional aggregate fields available in data.txt
  all_lecture_hours?: number;
  all_lab_hours?: number;
  all_practice_hours?: number;
  all_credits?: number;
  all_amount_hours?: number;

   // Новые поля из полного объекта
   name_direction?: number;
   department?: string;
   institute?: string;
   level_education?: string;
   type?: string;
   date_create?: string;
   creator_id?: number;
   employee_name?: string;
   employee?: Employee;
   sender_check?: string;
   sender_sign?: string;
   signatory?: Signatory;
   signatory_check?: string | null;
   signatory_sign?: string | null;
   status?: string;
   turn?: boolean;
   reason_reject?: string | null;
   syllabus_member?: SyllabusMember[];
}

export interface Employee {
  id: number;
  user: number;
  first_name: string;
  surname: string;
  surname_name: string;
  short_name: string;
  number_phone: string;
  imeag: string;
  email: string;
  division: string;
  position: string;
  is_online: boolean;
}

export interface Signatory extends Employee {}

export interface SyllabusMember {
  short_name: string;
  position: string;
  status: string;
  member_check: string | null;
  sign_unet: string | null;
  date_check_member: string | null;
}